import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;

import java.util.ArrayList;
import java.util.Random;

public class HandsOn7 extends Agent{
    protected void setup() {
        System.out.println("Agent "+getLocalName()+" started.");
        addBehaviour(new MyOneShotBehaviour());
    }
    private static int CantidadInd = 60;
    private static int CantidadIte = 1000000;
    private static ArrayList<Individuo> poblacion;// con la que se itera en cada ronda
    private static ArrayList<Individuo> supervivientes;// son los hijos que se crean despues de la combinacion
    private static ArrayList<Individuo> bloque;
    private static int posicionG = 0;

    private static boolean bandera = true;

    public static class Individuo
    {
        //Atributos de los individuos
        private long Genoma;
        private float Puntaje;
        private float Probabilidad;
        private float ProbabilidadAcumulada;
        private int BloqueMasAlto;

        public String getGenoma()
        {
            return DecimalToBinario(Genoma);
        }

        public void setGenoma(StringBuilder n)
        {
            this.Genoma = BinarioToDecimal(String.valueOf(n));
        }


        //pasa el genoma a binario y es mas facil pasarlo
        public String DecimalToBinario(long num)
        {
            if(num<0) //absoluto
            {
                num = num * -1;
            }
            long n = num;
            String bin = "";

            if(n == 0)
            {
                return "0000000000";
            }

            while(n>0)
            {
                if(n%2 == 0)
                    bin = "0" + bin;
                else
                    bin = "1" + bin;
                n = n/2;
            }

            while (bin.length() < 10) //FORZAR 8 bits
            {
                bin = "0" + bin;
            }

            return bin;
        }

        public long BinarioToDecimal(String binario)
        {
            long decimal = 0;
            int posicion = 0;
            // Recorrer la cadena...
            for (int x = binario.length() - 1; x >= 0; x--) {
                // Saber si es 1 o 0; primero asumimos que es 1 y abajo comprobamos
                short digito = 1;
                if (binario.charAt(x) == '0') {
                    digito = 0;
                }

              /*
                  Se multiplica el dígito por 2 elevado a la potencia
                  según la posición; comenzando en 0, luego 1 y así
                  sucesivamente
               */
                double multiplicador = Math.pow(2, posicion);
                decimal += digito * multiplicador;
                posicion++;
            }
            return decimal;
        }
    }

    public String DecToBin(long num)
    {
        if(num<0) //absoluto
        {
            num = num * -1;
        }
        long n = num;
        String bin = "";

        if(n == 0)
        {
            return "0000000000";
        }

        while(n>0)
        {
            if(n%2 == 0)
                bin = "0" + bin;
            else
                bin = "1" + bin;
            n = n/2;
        }

        while (bin.length() < 10) //FORZAR 8 bits
        {
            bin = "0" + bin;
        }

        return bin;
    }

    public static int getRandomNumberUsingNextInt(int min, int max) {
        Random random = new Random();
        return random.nextInt(max - min) + min;
    }
    //Crea una nueva lista
    public static void CrearPoblacion()
    {
        poblacion = new ArrayList<>();//Creacion
        supervivientes = new ArrayList<>();//creacion de hijos
        for (int i = 0; i < CantidadInd; i++) //Ciclo para las ireaciones que se desean realizar
        {
            Individuo ind = new Individuo(); // crea el individuo
            ind.Genoma = getRandomNumberUsingNextInt(1, 255); //B0 255  se genera un numero random
            poblacion.add(ind);// agrega individuo a la lista
        }
    }

    public static void Organizar(){
        //Metodo de burbuja
        boolean sw = false;
        while (!sw)
        {
            sw = true;
            for (int i = 1; i < poblacion.size(); i++)
            {
                if (poblacion.get(i).Puntaje > poblacion.get(i - 1).Puntaje)
                {
                    Individuo ind = poblacion.get(i);
                    poblacion.set(i, poblacion.get(i - 1));
                    poblacion.set(i - 1, ind);
                    sw = false;
                }
            }
        }
    }

    public static void DeterminarPuntajes(){
        for (int i = 0; i < CantidadInd; i+=6)
        {
            Individuo ind = bloque.get(i);
            Individuo ind2 = bloque.get(i+1);
            Individuo ind3 = bloque.get(i+2);
            Individuo ind4 = bloque.get(i+3);
            Individuo ind5 = bloque.get(i+4);
            Individuo ind6 = bloque.get(i+5);

            float resultado;
            resultado = bloque.get(i).Genoma + (2 * bloque.get(i+1).Genoma) -
                    (3 * bloque.get(i+2).Genoma) + bloque.get(i+3).Genoma +
                    (4 * bloque.get(i+4).Genoma) + bloque.get(i+5).Genoma;
            if(resultado > 30){
                resultado = 30/resultado;
            }
            else{
                resultado = resultado/30;
            }

            ind.Puntaje = resultado;
            ind2.Puntaje = resultado;
            ind3.Puntaje = resultado;
            ind4.Puntaje = resultado;
            ind5.Puntaje = resultado;
            ind6.Puntaje = resultado;
            bloque.set(i,ind);
            bloque.set(i+1,ind2);
            bloque.set(i+2,ind3);
            bloque.set(i+3,ind4);
            bloque.set(i+4,ind5);
            bloque.set(i+5,ind6);
        }
    }

    public static void Mostrar() throws InterruptedException {

        StringBuilder s = new StringBuilder();

        for (int i = 0; i < poblacion.size(); i++)
        {
            s.append(" Individuo").append("(").append(i).append(")").append(" Valor-").append(bloque.get(i).Genoma).append(" Fitness:").append(bloque.get(i).Puntaje+"\n");
            Thread.sleep(20);
        }
        System.out.println(s);
    }
    //Combinacion
    static void Combinacion()
    {
        float puntajeAcum = 0, puntajeAcumInd = 0, buff=0;
        float puntaje;

        //se determina el acumulado del porcentaje recorriendo toda la poblacion
        for(int i = 0; i < bloque.size(); i++)
        {
            puntaje = bloque.get(i).Puntaje; // guarda los puntajes
            puntajeAcum = puntajeAcum + puntaje; // acumula los puntaje para la determinacion
        }
        for(int i = 0; i < bloque.size(); i++) //Recorre la poblacion
        {
            Individuo ind = bloque.get(i);
            puntaje = bloque.get(i).Puntaje;
            puntajeAcumInd = puntaje/puntajeAcum;
            ind.Probabilidad = puntajeAcumInd;
            buff += puntajeAcumInd;
            ind.ProbabilidadAcumulada = buff;
            bloque.set(i,ind);
        }

        Random r = new Random();
        float randRuletaNum = 0 + r.nextFloat() * (bloque.get(bloque.size()-1).ProbabilidadAcumulada - 0);
        float randRuletaNum2 = 0 + r.nextFloat() * (bloque.get(bloque.size()-1).ProbabilidadAcumulada - 0);
        float bufferRuleta = 0, probabilidadActual;
        long temporal = 0;
        long temporal2 = 0;
        long temporal3 = 0;
        long temporal4 = 0;
        long temporal5 = 0;
        long temporal6 = 0;
        int bloque1;
        int bloque2;
        String Padre1 = "N"; //01010101  →  010101 10
        String Padre2 = "N"; //10101010  →  101010 01
        boolean Padre1Listo = false;
        boolean Padre2Listo = false;
        for(int i = 0; i < poblacion.size(); i++)
        {
            probabilidadActual = bloque.get(i).ProbabilidadAcumulada;
            if((bufferRuleta<randRuletaNum && randRuletaNum<=probabilidadActual) && Padre1Listo == false)
            {
                int numbloque = (i / 6);
                int pos = (numbloque * 6) - 1;
                if(pos == -1){
                    pos++;
                }
                if(i==59 || i==58){
                    i--;
                    i--;
                }
                Individuo ind = bloque.get(i);
                Individuo ind2 = bloque.get(i+1);
                Individuo ind3 = bloque.get(i+2);
                temporal = bloque.get(pos).Genoma;
                temporal2 = bloque.get(pos+1).Genoma;
                temporal3 = bloque.get(pos+2).Genoma;
                Padre1Listo = true;
                bloque1 = pos;
                ind.Genoma = temporal;
                supervivientes.add(ind);
                ind2.Genoma = temporal2;
                supervivientes.add(ind2);
                ind3.Genoma = temporal3;
                supervivientes.add(ind3);
                bloque.set(i,ind);
                bloque.set(i+1,ind2);
                bloque.set(i+2,ind3);
            }
            else
            {
                if((bufferRuleta<randRuletaNum2 && randRuletaNum2<=probabilidadActual) && Padre2Listo == false)
                {
                    int numbloque = (i / 6);
                    int pos = (numbloque * 6) - 1;
                    if(pos == -1){
                        pos++;
                    }
                    if(i==59 || i==58){
                        i--;
                        i--;
                    }
                    Individuo ind = bloque.get(i);
                    Individuo ind2 = bloque.get(i+1);
                    Individuo ind3 = bloque.get(i+2);
                    temporal4 = bloque.get(pos).Genoma;
                    temporal5 = bloque.get(pos+1).Genoma;
                    temporal6 = bloque.get(pos+2).Genoma;
                    Padre2Listo = true;
                    bloque2 = pos;
                    ind.Genoma = temporal4;
                    supervivientes.add(ind);
                    ind2.Genoma = temporal5;
                    supervivientes.add(ind2);
                    ind3.Genoma = temporal6;
                    supervivientes.add(ind3);
                    bloque.set(i,ind);
                    bloque.set(i+1,ind2);
                    bloque.set(i+2,ind3);
                }
                else {
                    bufferRuleta = probabilidadActual;
                }
            }
            //Correcion de error para obligar a poner un papa
            /*if(i == poblacion.size()-1)
            {
                long siFalla=0;
                if(Padre1 == "N")
                {
                    siFalla = bloque.get(getRandomNumberUsingNextInt(0, bloque.size()-1)).Genoma;
                    Padre1 = ind.DecimalToBinario(siFalla);
                }
                if(Padre2 == "N")
                {
                    siFalla = bloque.get(getRandomNumberUsingNextInt(0, bloque.size()-1)).Genoma;
                    Padre2 = ind.DecimalToBinario(siFalla);
                }
            }*/

        }
    }

    static void Mutacion(){
        long GenomaHijo;
        long temporal;
        StringBuilder SGenoma;
        float ratioMutacion = 0.05f; //
        Random r = new Random();
        for(int i=0; i< supervivientes.size(); i++)
        {
            float randRatioMutacion = 0 + r.nextFloat() * (1 - 0);
            if(randRatioMutacion < ratioMutacion)
            {
                int ran =  (int)Math.random()* 6 + 0;
                Individuo ind = supervivientes.get(i+ran);
                int nuevoGenoma = (int)Math.random()* 150 + 0;
                ind.Genoma = nuevoGenoma;
                bloque.set(i,ind);
            }
        }
    }

    static void ReemplazarPoblacion()
    {
        bloque = new ArrayList<>();
        for(int i = 0; i < supervivientes.size(); i++)
        {
            bloque.add(supervivientes.get(i));
        }
        supervivientes = new ArrayList<>();
    }

    static void CrearGrupo(){
        bloque = new ArrayList<>();
        for(int i=0; i<60; i++){
            int ran =  (int)Math.random()* CantidadInd + 0;
            bloque.add(poblacion.get(i));
        }
    }


    private class MyOneShotBehaviour extends OneShotBehaviour
    {

        public void action()
        {
            boolean bandBreak = false;
            CrearPoblacion(); //Crea la poblacion inicial
            CrearGrupo();
            int ite = 0;
            for (int i = 0; i < CantidadIte; i++) //posible a modificar
            {
                DeterminarPuntajes();
                Organizar();
                try {
                    Mostrar();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                int j =0;
                //Determina los genomas para saber si son 168
                while(j < bloque.size())
                {
                    if(bloque.get(j).Puntaje == 1)
                    {
                        bandBreak = true;
                    }
                    j++;
                }
                if(bandBreak == true)
                {
                    break;
                }
                else
                {
                    while (supervivientes.size() < bloque.size()) {
                        Combinacion();
                    }
                    Mutacion();
                    ReemplazarPoblacion();
                    ite++;
                }
            }
            System.out.println("FIN  " + ite++);
        }
    }
}